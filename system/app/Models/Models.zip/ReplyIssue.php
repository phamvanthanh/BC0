<?php

namespace system\Models;

use Illuminate\Database\Eloquent\Model;

class ReplyIssue extends Model
{
    //
}
