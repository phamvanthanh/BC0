<?php

namespace system\Models;

use Illuminate\Database\Eloquent\Model;

class Gwbs extends Model
{
    protected $table = 'gwbs';
    protected $fillable = [
        'group_id',
        'code'
    ];
}
