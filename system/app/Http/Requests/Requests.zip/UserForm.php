<?php

namespace system\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use system\Models\User;

class UserForm extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
    
       return $this->user()->can('create-update-user');    
       
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
             'first_name'=>'required | string',
             'last_name' =>'required | string',
             'email'     =>'required | email',
             'nation_id' =>'required | integer',
             'status'    =>'required | integer'
            
        ];
    }
    public function persist() {

        $inputs = $this->only([
            'first_name', 
            'last_name', 
            'email', 
            'phone',
            'organization',
            'nation_id', 
            'status',         
            'created_by']);

        if($this->has('id')) {           
            User::where('id', $this->input('id'))->update($inputs);
            return response(['User post succeed'], 200);
        }
   
       
        $inputs['password'] = hash('md5', rand());
       
        User::create($inputs);   
        return response(['User post succeed'], 200);
       
    }
}
