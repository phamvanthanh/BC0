<?php

namespace system\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use system\Models\Wbs;
use system\Models\Pwbs;

class WbsForm extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return $this->user()->can('create-delete-wbs');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'code'        => 'required | integer',
            'name'        => 'required | string',
            'parent_code' => 'required | integer'
        ];
    }
    
    public function persist() {

        Wbs::updateOrCreate(
            ['code' => $this->input('code')],
            $this->all()
        );

       return response(['Wbs post succeed.'], 200);
    }

    public function delete() {
             $request = $this->all(); 
             
             $pwbs_exist = Pwbs::where(function ($query) use($request) {
                $query->where('code', '=', $request['code'])
                    ->orWhere('parent_code', '=', $request['code']);
            })->first();

          
        
            if(!$pwbs_exist) {
            
                Wbs::where('code', $request['code'])          
                ->delete();
                return response(['Delete wbs item succeed'], 200);
            }

            return response(['This item is in used in projects.'], 400);

            


    }
}
