<?php

namespace system\Http\Controllers;

use Illuminate\Http\Request;
use system\Models\Section;
use system\Http\Requests\SectionForm;
use system\Models\Job;

class SectionsController extends Controller
{
    public function index($pid){

        return Section:: where('project_id', $pid)->with('job')->get();
    }
    public function show($gid) {

        return Section::with('job')->find($gid);
    }
    public function store(SectionForm $form){

        return $form->persist();
    }
    public function delete(Request $request){
        
        Job::where('jobable_id', $request['id'])->where('jobable_type', 'section')->delete();
        Section::find($request['id'])->delete(); 
    }
}
