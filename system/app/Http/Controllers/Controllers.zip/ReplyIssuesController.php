<?php

namespace system\Http\Controllers;

use Illuminate\Http\Request;

class ReplyIssuesController extends Controller
{
    //
}
