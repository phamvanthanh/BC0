<?php

namespace system\Http\Controllers;

use Illuminate\Http\Request;

class JobHoldersController extends Controller
{
    //
}
