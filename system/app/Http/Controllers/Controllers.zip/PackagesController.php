<?php

namespace system\Http\Controllers;

use Illuminate\Http\Request;
use system\Models\Section;
use system\Models\Package;
use system\Http\Requests\PackageForm;
use system\Models\Job;
use DB;
use system\Http\Controllers\QuantityController;

class PackagesController extends Controller
{

    protected function leaves($jid) {
       
        $pk = new QuantityController;
        return $pk->pullJobItems($jid); 
    }

    public function index($gid) {

       return Package::where('group_id', $gid)                                                             
                         ->with('job')->get();  
       
        // foreach($packages as $index => $package) {
            
        //     $leaves = $this->leaves($package->job->id);
            
        //     $num = count($leaves);
        //     $commit_values = collect($leaves)->pluck('commit')->all();
        //     $committeds = array_count_values($commit_values);          
            
        //     if(isset($committeds['true']))
        //         $committeds = $committeds['true'];   
        //     else 
        //         $committeds = 0;
            
        //     // $packages[$index]->quantum = $num *$package['area']*$package['complexity'];
        //     // $packages[$index]->cmtd_quantum = $committeds *$package['area']*$package['complexity'];
        // }
        // return $packages;
    }

    public function showByProjectId($pid) {

        $groups   = Section::where('project_id', $pid)->select('id')->get();

        $groupArr = collect($groups)->map(function ($ob) {
                            return ($ob->id);
                    });
        return Package::whereIn('group_id', $groupArr)->with('group')->get();
    }

    public function show($pkid) {
        return Package::find($pkid);
    }

    public function store(PackageForm $form) {
       return $form->persist();                
    }
    
    public function delete(Request $request){
        Job::where('jobable_id', $request['id'])->where('jobable_type', 'package')->delete();
        Package::find($request['id'])->delete(); 
    }
   
}
   