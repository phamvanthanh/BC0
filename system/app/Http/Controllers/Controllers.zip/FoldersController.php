<?php

namespace system\Http\Controllers;

use Illuminate\Http\Request;
use system\Models\Folder;
use system\Http\Requests\FolderForm;


class FoldersController extends Controller
{
    public function index($pid) {
        return Folder::where('project_id', $pid)->get();        
    }

    public function store(FolderForm $form){
        return $form->persist();
    }
    
    public function delete(Request $request){

        Folder::find($request['id'])->delete();

        return response(['Folder delete succeed'], 200); 
    }
}
