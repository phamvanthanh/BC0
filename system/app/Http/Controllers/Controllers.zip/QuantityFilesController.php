<?php

namespace system\Http\Controllers;

use Illuminate\Http\Request;
use system\Models\QuantityFile;
use system\Models\Quantity;
use Sail\Models\Project;
use Maatwebsite\Excel\Facades\Excel;

class QuantityFilesController extends Controller
{
    public function upload($request) {             
        
        $file = $request->file('file');
         $extension = $file->extension();       
        
         $quantity_records = Excel::load($file)->first()->first();          
        //Get the quantity from the file            

        //Check for code match
        if($request['code'] == $quantity_records['code']) {
            
            //If match update to table quantity or create new quantity record
            $quantity = Quantity::updateOrCreate(
                ['id'=>$request['id']],
                [
                    'job_id'=>$request['job_id'],
                    'code'=>$request['code'],
                    'quantity'=>$quantity_records['quantity']
                ]
            );

            //Move file to place
            $path = storage_path('quantities');
            $name = $quantity['id'].'_'.$request['code'].'.'.$extension;
            $file->move($path, $name);
      
            // Get the quantity_id from return quantity model and update the quantity_files table
            QuantityFile::updateOrCreate(
            
                ['quantity_id' => $quantity['id']],
            
                [   'name' => $name,
                    'path' => $path.'/'.$name        
                ]
            
            );

             return response(['File import succeed'], 200); 
        }
            
     

    }
  
}


