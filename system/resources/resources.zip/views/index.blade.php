
<!DOCTYPE html>


<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--<meta name="csrf_token" content="{!! csrf_token() !!}"/>-->
	 <meta name="csrf-token" content="{{ csrf_token() }}">
	<title>BreakCost</title>

	<script type="text/javascript" src="/js/extensions/core/libraries/jquery.min.js"></script>
	<script type="text/javascript" src="/js/extensions/core/libraries/bootstrap.min.js"></script>



	<link href="/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
	<link href="/css/bootstrap_mod.css" rel="stylesheet" type="text/css">
	<link href="/css/app.css" rel="stylesheet" type="text/css">

	

  


</head>

<body>
@if(Auth::check())
<div id="app" >
<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
		{{ csrf_field() }}
</form>

<router-view v-if="loggedIn" ></router-view>
			
	
</div>
 <script type="text/javascript" src="/js/app.js"></script>
@else
	<script>window.location = "login";</script>
	
@endif

</body>
</html>

    