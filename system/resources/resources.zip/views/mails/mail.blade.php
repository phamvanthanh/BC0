<html>
<h1>Mail is sent</h1>
</html>