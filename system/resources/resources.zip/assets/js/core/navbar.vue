<template>
<nav class="navbar">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="nav-brand"  href="#"><span style="font-family: 'Raleway'"> BreakCost</span></a>
      </div>
      <ul class="nav navbar-nav">
        <li><a @click="goBack"  class="pr-0"><i class="icon-arrow-left8"></i></a></li>
        <li><a @click="forward" class="pr-0"><i class="icon-arrow-right8"></i></a></li>
        <li><a class="pr-0"><slot name="crumbs"></slot></a></li>
      </ul>
       <ul class="nav navbar-nav navbar-right">
          <li v-if='$can("surveyor|qto_controller|project_manager|project_director|superuser")'><router-link data-toggle="tooltip" data-placement="top" title="Forms" to="/forms" ><i class="icon-insert-template"></i></router-link></li>
          <li v-if='$can("surveyor|qto_controller|project_manager|project_director|superuser")' ><router-link data-toggle="tooltip" data-placement="top" title="Messanger" to="/messenger"><i class="icon-bubble-dots4"></i></router-link></li>
          <li class="dropdown">
        
            <a  href="#" class="dropdown-toggle" data-toggle="dropdown" id="dropdown1" >
              <img src="" alt="">
              
                <span>{{user.first_name}}</span>
            
              <i class="caret"></i>
            </a>
          
          
            <ul  class="dropdown-menu" aria-labelledby="dropdown1" >

                  <li  >
                    <a href="#" @click.prevent="stay"  class="accordion  has-ul" >
                       
                        <span>Your Roles</span>
                    </a>
                    <ul class="panel accordion-content hidden " >
                          <li v-for="role in user.roles" ><a href="#"  >{{role.display_name}}</a></li>           
                            
                    </ul>
                  </li>
                  <li><a href="#">My Account</a></li>
                  <li>    
                      <a href="#"
                              onclick="event.preventDefault();
                                          document.getElementById('logout-form').submit();">
                              Logout
                      </a>  
                  </li>   
                
                
                  
            </ul>
                
          </li>                 
      </ul>
    </div>
</nav>
     
   
</template>

<script>
export default {

  computed : {
    user: function() {
      return this.$store.state.user;
     }
  },
  methods: {
    stay(e) {      
        e.stopPropagation();
        var x = $('ul.panel.accordion-content').toggleClass('hidden');
        $(e.target).toggleClass('active');;
    },
    goBack() {
            router.go(-1);
    },

    forward() {
        router.go(1);
    },

   
  
  }
}


</script>

