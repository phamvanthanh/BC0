<template>
  <div v-cloak  class="wrapper">
	  <navbar >	
			<vs-crumbs slot="crumbs" ></vs-crumbs>		
	  </navbar>
	  <sidebar ></sidebar>
	  <maincontent  ></maincontent>
  </div>
  


</template>

<script>
import navbar from './navbar';
import sidebar from './sidebar';
import maincontent from './content';
require ('./breadcrumbs.vue')

export default {
	data() {
		return {
			accessLogged: false
		}
		
	},
	components: {
		navbar,
		sidebar,
		maincontent
	},

	


  
 

}
</script>





