<template>


</template>
<script>
export default {
    props: ['issue']
}

</script>