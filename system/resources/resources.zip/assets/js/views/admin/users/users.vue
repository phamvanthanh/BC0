<template>
<div class="content-wrapper">
    <!-- Page header -->
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
                <window-heading2></window-heading2>        
            </div>

            <div class="heading-elements">
                <div class="heading-btn-group" >
                   
                </div>
            </div>
        </div>

    
    </div>

    <div class="content">
        <div class="panel panel-flat">
            <div class="panel-heading">                
                <div class="heading-elements">
                    <div class="heading-btn">
                        <div class="form-group">
                            <div class="switch-box">												  
                                <label class="switch ">	
                                    <span class="switch-label">Edit</span>																										
                                    <input v-model="editMode" @click="editToggle"type="checkbox" name="edit" >                                    
                                    <div class="slider"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
            <div class="panel-body">
                <div class="col-md-12" v-if="editMode">
                    <form method="post" @submit.prevent="onSubmit" >                                   
                        
                            <div class="col-md-3 pl-5">
                                <div class="form-group">
                                    <label >First Name:</label>
                                    <input v-model="form.first_name"  type="text" placeholder="First name" class="form-control">
                                </div>
                            </div>

                            <div class="col-md-3"> 
                                <div class="form-group">
                                    <label >Last Name:</label>
                                    <input v-model="form.last_name"   type="text" placeholder="Last name" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-3"> 
                                <div class="form-group">
                                    <label >Nation:</label>
                                    <select v-model="form.nation_id"   type="text" placeholder="Nation" class="form-control">
                                        <option></option>                                    
                                        <option value="1">United States</option>
                                        <option value="2">Canada</option>                                        

                                        <option value="3">Chile</option>
                                        <option value="4">Argentina</option>
                                        <option value="5">Colombia</option>
                                        <option value="6">Peru</option>                                        

                                        <option value="8">Croatia</option>
                                        <option value="9">Hungary</option>
                                        <option value="10">Ukraine</option>                            

                        
                                        <option value="21">Egypt</option>
                                        <option value="22">Israel</option>
                                        <option value="23">Nigeria</option>
                                        <option value="24">United Arab Emirates</option>                                     

                                
                                        <option value="26">Australia</option>
                                        <option value="27">China</option>
                                        <option value="28">India</option>
                                        <option value="29">Singapore</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3"> 
                                <div class="form-group">
                                    <label >Email:</label>
                                    <input v-model="form.email"   type="text" placeholder="Email" class="form-control">
                                </div>
                            </div>          
                            
     
                            <div class="col-md-3 pl-5"> 
                                <div class="form-group">
                                    <label >Phone:</label>
                                    <input v-model="form.phone"   type="text" placeholder="phone" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-3"> 
                                <div class="form-group">
                                    <label >Organization:</label>
                                    <input v-model="form.organization"   type="text" placeholder="Orginization" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Status:</label> 
                                    <div class="input-group input-sm">
                                        <label class="radio-inline"><input type="radio"   value="1" v-model="form.status" checked>Enable</label>
                                        <label class="radio-inline"><input type="radio"   value="0" v-model="form.status" >Disable</label>
                                    </div>
                                </div>
                            </div>                       
                            <div class="col-md-1">
                                <div class="form-group">
                                    <label class="transparent" >*</label>
                                    <button type="submit" class="btn btn-primary  form-control">Save</button>
                                </div>

                            </div>
                            <div class="col-md-1">
                                <div class="form-group">
                                    <label class="transparent" >*</label>
                                    <button @click.prevent="clearForm" class="btn-default  form-control">Clear</button>
                                </div>

                            </div>
                       	
                    </form>
                </div>
                <div class="col-md-12">

                     <v-client-table 
                            :data="users" 
                            :columns="columns" 
                            :options="options">
                            <template slot="actions" scope="props">
                                 <ul class="icons-list" >
                                    <li class="dropdown" >
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                            <i class="icon-menu7"></i>
                                        </a>

                                        <ul class="dropdown-menu  dropdown-menu-right">
                                            <li><router-link class="text-primary" :to="{name: 'admin.user', params: {uid: props.row.id}}"><i class=" icon-profile"></i> Profile</router-link></li>
                                            <li><a @click="editUser(props.row)" class="text-primary"  ><i class="icon-pencil3"></i> Edit</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </template>
                            
                   
                      </v-client-table>

                </div>
            </div>        
        </div>
       
    </div>
    <notify :warns="$store.state.notifications"></notify>
</div>

</template>
<script>

import  ClientTable from 'vue-tables-2';
import notify from './../../../core/Notify';


export default {
  
    data() {
        return {
             editMode: (localStorage.getItem('usersedit') =="false"? false: true),
         
             form: new Form({
                 id: null,
                 first_name: null,
                 last_name: null,
                 nation_id: null,                
                 email: null,
                 phone: null,
                 organization: null,
                 status: null                
                 
             }),

             users: [],
             columns: ['id', 'full_name', 'nation_abbr', 'email', 'phone', 'organization', 'status', 'actions'],
             options: {
             
                headings: {
                    full_name: 'Name',
                    nation_abbr: 'Nation',
                    origanization: 'Ogr',
                    actions: ''
                },

                templates: {      
                    status: 'status'
                },
                
                skin: 'table-hover',
                
                texts: {
                    filter: ''
                },
                
                columnsClasses: {
                  
                    id: 'w-70',
                    full_name: 'column-expanded',
                    client: 'w-150',
                    nation_abbr: 'w-70',
                    email: 'w-200',
                    phone: 'w-125',                 
                    organization: 'w-200',
                    status: 'w-70',   
                    actions: 'text-right w-40 action',
                },
                
                sortIcon: { 
                    base: '',  up:'icon-arrow-up5', down:'icon-arrow-down5'

                },
             }
        
        }

    },

    components: {
        notify,
    },

    created() {        
        this.getUsers(this.pid);
        var _this = this;

        bus.$on('refreshusers', function(){
            _this.getUsers(_this.pid);
        });

        bus.$on('edituser', function(e){ 
                    
            for(let property in e){
                _this.form[property] = e[property];
            }
        })
    },
    computed: {

        notifications() {
            return this.$store.state.notifications
        },
        
    },

    methods: {

        editToggle() {
            localStorage.setItem('usersedit', this.editMode);
        },

        onSubmit() { 
            this.form.post('/api/admin/users')
                     .then(({data})=>{
                         notice(this.form.notifications, 5000);
                         this.form.reset();
                         this.getUsers(this.pid)
                     })
                     .catch(({error})=>{
                        notice(this.form.notifications, 5000);  
                     })

        },

        getUsers(pid) {
            axios.get('/api/admin/users')
                 .then((data)=>{this.users = data.data.map(function(e){
                     e.full_name = e.first_name + ' ' + e.last_name;
                     e.nation_name = e.nation.name;
                     e.nation_abbr = e.nation.abbreviation;
                     
                     return e;
                 }) })
        }, 
        editUser(e) {
            if(!this.editMode)
                this.editMode =true;
            bus.$emit('edituser', e);
        },
        clearForm() {
            this.form.reset();
        },   
        

    }


}
</script>
