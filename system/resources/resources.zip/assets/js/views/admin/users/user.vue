<template>
<div class="content-wrapper">
   
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
               <span>{{$route.meta.display}}</span>  
            </div>

            <div class="heading-elements">
                <div class="heading-btn-group" >
                   
                </div>
            </div>
        </div>

    
    </div>
 
    <div class="content">

        <roles :user="user"></roles>

        <jobs :uid="user.id"></jobs>

       		

      <notify  :warns="$store.state.notifications" ></notify>
    </div>  

</div>

</template>
<script>
import notify from './../../../core/Notify';

import roles from './user/roles';
import jobs from './user/jobs';



export default {
  
    data() {
        return {
                  
             uid: this.$route.params.uid,
      
             user:  {
                 id: null,
                 first_name: null,
                 last_name: null,
                 roles: []
             },
           
        }

    },
    
    created() { 
        var _this = this;   
        this.getUser(); 
        bus.$on('refreshuser', function(){
            _this.getUser();
        });    
     
   
    },
    computed: {
        
        full_name() {
            return this.user.first_name + ' '+ this.user.last_name;
        }      
    },
    components: {

           notify,
           roles,
           jobs
          
    },
    methods: {
 

        getUser() {
            axios.get('/api/admin/users/'+this.uid)
                 .then(({data})=>{
                     this.roles = data.roles.map(function(e){
                         e.user_id = data.id;
                         return e;
                     })
                     this.user = data; })
                 .catch((error)  => console.log(error));
        }, 
  

        goBack() {
            router.go(-1);
        },
        forward() {
            router.go(1);
        }       

    }


}
</script>
