<template>
    <router-view>
    </router-view>
    
</template>
<script>
    require ('./../../core/breadcrumbs.vue')
</script>