<template>
	<div>
		<h1>Opps, page not found</h1>
	</div>
</template>

<script>
export default{
	name: 'lv-error',
}
</script>