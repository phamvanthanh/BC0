 <template>
<div class="content-wrapper">
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
                <window-heading2></window-heading2>              
            </div>
            <div class="heading-elements">
               
            </div>
        </div>    
    </div>
    <div class="content">
        <router-view  name="info" :info="info" >
            <button  slot="buttons"  class="btn btn-success">Bid</button>
        </router-view>
        <router-view  name="jwbs" :info="info" >
            <h6 slot="jwbs-title" class="panel-title">Jwbs</h6>    
        </router-view>     
    </div>
</div>
</template>
<script>

import {capitalize} from './../../core/filters';
 
export default {
    data() {
        return {
           
              id: this.$route.params.id,
              info: {
                  status: null,
                  awarded: { },
                  project: { 
                      name: null,
                      industry: {
                          name: null
                      },
                      nation: {
                          name: null
                      }
                  },                 
                  jobable: {},
                  bids: []
              } 
        }
    },
     props: {
        user: {

        },
        
    },
    
    created() {       
        this.getJob();
    },
   
    methods: {
        
        getJob() {
           
            axios.get('/api/works/'+this.id)
                 .then(({data})=>{
                            data.from_date = data.from_date;
                            data.to_date = data.to_date;
                            data.jobable_type = data.jobable_type;
                            data.status = data.status
                            this.info = data;
                            this.$store.commit('loadItem', {label:capitalize(data.jobable_type), name: data.jobable.name});
                 })
                 .catch((error)=>console.log(error));
        },
   

    }
    


}
    

</script>