<template > 
<li>
    <div  class="wbs-item">
        <span :class="{bold: isFolder}" class="wbstree-expander"
              @click="toggle" v-if="isFolder">[{{open ? '-' : '+'}}]
        </span>					
        <span > 
            {{node.code + ' - ' + node.name}}
        </span>
    </div>
    <ul v-show="open" v-if="isFolder">
        <pwbs           
            v-for="node in node.children" 
            :key="node.code"
            :node="node" >
        </pwbs>								
    </ul>
</li>
</template>
<script>

import treemixin from './treemixin';

export default {
    mixins: [treemixin],
    name: 'pwbs',   
    props: {
        node: {},
    },
   



}
</script>