<template>
    <newproject>

    </newproject>
</template>

<script>
import newproject from './new/info';

require ('./../../../core/breadcrumbs.vue')

export default {

    components: {
        
        newproject
    }

}
</script>