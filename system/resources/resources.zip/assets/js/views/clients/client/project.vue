<template  >
<div class="content-wrapper">
    <!-- Page header -->
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
                <window-heading2></window-heading2>
            </div>

            <div class="heading-elements">
                <div class="heading-btn-group" >
                     <router-link :to="{name:'client.project.info', params: {pid: pid}}" class="btn btn-link btn-float has-text">     <i class="icon-info22 text-primary"></i><span>Info</span></router-link> 
                     <router-link :to="{name:'client.project.files', params: {pid: pid}}" class="btn btn-link btn-float has-text">    <i class="icon-files-empty text-primary"></i><span>Files</span></router-link>
                     <router-link :to="{name:'client.project.links', params: {pid: pid}}" class="btn btn-link btn-float has-text">    <i class="icon-link text-primary"></i><span>Links</span></router-link>                    
                     <router-link :to="{name:'client.project.pwbs', params: {pid: pid}}" class="btn btn-link btn-float has-text">     <i class="icon-list-ordered text-primary"></i><span>Pwbs</span></router-link>                      
                     <router-link :to="{name:'client.project.reports', params: {pid: pid }}" class="btn btn-link btn-float has-text"> <i class="icon-statistics text-primary"></i><span>Reports</span></router-link>
                     <router-link :to="{name:'client.project.quantity', params: {pid: pid }}" class="btn btn-link btn-float has-text"> <i class="icon-statistics text-primary"></i><span>Quantity</span></router-link>                     
                     <router-link :to="{name:'client.project.issues', params: {pid: pid }}" class="btn btn-link btn-float has-text">  <i class="icon-notification2 text-primary"></i><span>Issues</span></router-link>
                </div>
            </div>
        </div>

    
    </div>

    <div class="content">
        <router-view 
            :pid="pid" 
            :id="pid"
            :job_id="project.job.id"
            :job="project.job" >
        </router-view>   
         <notify :warns="$store.state.notifications"></notify>
    </div>

</div>
</template>

<script>
  
import notify from './../../../core/Notify';

export default {
    data() {
        return {
            pid : this.$route.params.pid,
            project: {
                job: {
                    id: null,
                }
            },
        }
    },
    
    created() {
        if(this.pid)
        this.getProject(this.pid);
    },     
    
    components: {                    
        notify                   
    },
    methods: {
        
        getProject(id) {
            axios.get('/api/projects/'+id)
                    .then(({data})=>{
                        this.$store.commit('loadItem', {label:'Project', name: data.name});

                        this.project = data})
                    .catch(({error})=>{console.log(error)})
        },
       
    }
    
}
</script>
