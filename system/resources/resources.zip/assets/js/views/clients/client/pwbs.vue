<template>

    <div class="panel panel-flat" >
      <div class="panel-heading">	
        <h6 class="panel-title">Pwbs</h6>					
        <div class="heading-elements">
          <div class="heading-btn">
            <div class="form-group">             
                    							
              
            </div>								
          </div>
          
        </div>					
      </div>
    
      <div class="panel-body"  >						
              
          <div  class="col-md-12">
          
              <ul id="pwbs-static-ul">							
                  <pwbs										
                      :node="pwbs"  >
                  </pwbs>
              </ul>	
           
          </div>
     					
      </div>
   
    </div>		
  
</template>
<script>

import pwbs from './../../elements/pwbs';


export default {
    props: {
      id: null
    },
    data() {
        return {

            pwbs: [],      
      
        }
    },
    created() {
        
        this.getPwbs(this.id);  
       

    },


    components: {

        pwbs,
   
    },
    methods: {

      getPwbs: function(pid) {
        axios.get('/api/projects/'+this.id+'/pwbs') 
            .then(({data})=>{this.pwbs = data});
      }    
    }
}

  

</script>


