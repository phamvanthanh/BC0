<template>
<div>
    <chartjs-line></chartjs-line>
</div>
</template>
<script>
import 'moment';
import 'chart.js';
import 'hchs-vue-charts';
export default {

}
</script>