<template>
<div>
    <h5>Admin dashboard</h5>
    <h6>Dashboard items</h6>


    <ul>
        <li>User Management</li>        
        <li>Roles Management</li>        
        <li>Permissions</li>
        <li>Assets</li>

        
    </ul>
</div>
</template>
