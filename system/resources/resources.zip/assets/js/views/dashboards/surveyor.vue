<template>
<div>
    <h5>Packages dashboard</h5>
    <h6>Dashboard items</h6>


    <ul>
        <li>Team's message</li>        
        <li>Items / New items commit</li>        
        <li>Packages progress</li>
        <li> New jobs feeds</li>

        
    </ul>
</div>
</template>
