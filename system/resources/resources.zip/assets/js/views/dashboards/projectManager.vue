<template>
<div>
    <h5>Project dashboard</h5>
    <h6>Dashboard items</h6>


    <ul>
        <li>Project team's message</li>
        <li>Groups / New Groups Commit</li>
        <li>Packages / New packages commit</li>
        <li>list of project / quantum / quantitfied quantum / audit quantum</li>
        <li>Project progress</li>
        <li>New jobs feed</li>

        
    </ul>
</div>
</template>
