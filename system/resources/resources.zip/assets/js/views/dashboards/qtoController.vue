<template>
<div>
    <h5>Group dashboard</h5>
    <h6>Dashboard items</h6>


    <ul>
        <li>Team's message</li>        
        <li>Packages / New packages commit</li>
        <li>list of groups / quantum / quantitfied quantum / audit quantum</li>
        <li>Groups progress</li>
        <li>New jobs feeds</li>

        
    </ul>
</div>
</template>
