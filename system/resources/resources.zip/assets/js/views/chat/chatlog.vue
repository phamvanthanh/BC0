<template>
<div >
	 <div @scroll="scrollFunction" class="chatroom-log pr-20" id="chatroom-log" >
        <div v-if="!job.id" id="chatwelcom">
            <h5 class="welcome-message"> Choose a job discuss about </h5>
        </div>
        <div v-if="job.id">
            <ul    id="chat-list" class="media-list chat-list content-group">
                <li v-for="message in messages" :id="'item'+message.id" class="media">
                    <div  >
                        <div v-if="message.day" class="display-block text-center day-block" >
                            <span class="badge badge-default"> {{message.day}}</span>
                        </div>

                        <div class="media-head" v-if="message.isHeader" >
                            
                            <span class="fw-600">#{{message.job_id}} - {{message.job.jobable.name}}</span>
                            <span class="text-size-small text-muted">{{message.title}}</span>
                            
                        </div>
                        

                        <div class="media-body"  >
                            <div :class="[{first: message.isHeader, guest: message.isGuest}, 'media-content ml-30 display-block']">
                                    <span  v-cloak  v-html="message.message"></span>
                                    <span class="media-annotation display-block">{{message.time}} </span>
                            </div>
                            
                        </div>
                  </div>
                </li>               

            </ul>          
        </div>
    </div>
</div>
        
   
   
    
  
</template>

<script>

export default {
    props: ['job'],

    data() {
        return {
            messages: [],
            isProcessing: false,
            show: false
        }        
    },
    created() {
        let _this = this;
        this.getMessages(this.job.id);

        bus.$on('getmessages', function() {
            _this.getMessages(_this.job.id);
        });

        var pusher = new Pusher('991d2a15bf97b4ea1687', {
        cluster: 'ap1',
        encrypted: true
        });

        var i;

        for(i = 0; i < this.job.relateds.length; i++) {
             let id = this.job.relateds[i];

             var channel = pusher.subscribe('chatroom'+id);  
             channel.bind('Snail\\Events\\MessagePosted', function(data) {
                    let last = _this.messages[_this.messages.length-1];
                    let message = _this.formatNewMessage(data, last, _this.job.id)
                    
                    _this.messages.push(message);
             });          
        }
        
               
    },
    updated() {    
        // this.updateScroll();
        let _this = this;   
      
    },    

    watch: {
        'job.id' : function(val) {
            this.getMessages(val);
        }
    },

    methods: {
        getMessages(id, last_id) {
            if(id)
			axios.get('/api/messages/jobs/'+id+'/last/'+last_id)
				 .then(({data})=>{
                     if(data.length > 0) 
                         this.messages = this.formatMessages(data, this.$store.state.user.id); 
                     else 
                        this.messages = [];
                     let _this = this;
                     setTimeout(function(){
                        _this.updateScroll()
                        _this.show = true;}, 1);         
				 })
                 .catch((error) => {
                     console.log(error);
                 });
		},
 

        updateScroll(){
        
            var  element = this.$el.querySelector("#chatroom-log");
            element.scrollTop = element.scrollHeight + 80;
        
            
        },

        formatMessages(data, id) {
                var i;
                data[0].isHeader = true; 
                data[0].day = moment(data[0].created_at).format('lll');
                data[0].isDay = true;
                if(data[0].user_id != id)
                data[0].isGuest = true;

                 if(data[0].job.jobable_type == 'project') {
                       
                    if(data[0].job.jobable.user_id == data[0].user_id) {
                           
                            data[0].title = 'Client';
                                         
                        }              
                       
                        else
                            data[0].title = 'Project Manager';
                    }
                        

                    if(data[0].job.jobable_type == 'group')
                        data[0].title = 'Controller';
                    
                    if(data[0].job.jobable_type == 'package')
                        data[0].title = 'Surveyor';
                
          

                for(i=1; i < data.length; i++) {
                    if(data[i].user_id != id)
                    data[i].isGuest = true;
                    if(data[i].user_id == data[i-1].user_id) {
                        data[i].isHeader = false;
                    }
                    
                    else {
                        data[i].isHeader = true;
                    }                   
                    
                    
                    var lastday = moment(data[i-1].created_at).format("MMM Do YY"); 
                    var nowday = moment(data[i].created_at).format("MMM Do YY");
                    
                    
                    if(nowday != lastday){
                        data[i].isDay = true;
                        data[i].day = moment(data[i].created_at).format('lll');                        
                    }                           
                    else {
                        var lasttime = moment(data[i-1].created_at).format('LT');
                        var nowtime = moment(data[i].created_at).format('LT');
                        if(lasttime != nowtime || data[i].job.id != data[i-1].job.id)
                            data[i].time = nowtime;                           

                    }

                    if(data[i].job.jobable_type == 'project') {
                       
                        if(data[i].job.jobable.user_id == data[i].user_id) {
                           
                                         data[i].title = 'Client';
                                         
                        }              
                       
                        else
                            data[i].title = 'Project Manager';
                    }
                        

                    if(data[i].job.jobable_type == 'group')
                        data[i].title = 'Controller';
                    
                    if(data[i].job.jobable_type == 'package')
                        data[i].title = 'Surveyor';

                }            
                return data;
        },

        formatNewMessage(data, last, id) { 
               
                let message = data.message;
                message.job = data.job;
                message.job.jobable = data.jobable;

                if(message.job_id != id)
                    message.isGuest = true;
                if(last.job_id) {
                    if(message.job_id == last.job_id)
                        message.isHeader = false;
                    else 
                        message.isHeader = true;
                }
                else
                    message.isHeader = true;
            
                
                let lastday = moment(last.created_at).format("MMM Do YY");
                let nowday = moment(message.created_at).format("MMM Do YY");


                if(nowday != lastday){
                    message.isDay = true;
                    message.day = moment(message.created_at).format('lll');                        
                }                           
                else {
                    var lasttime = moment(last.created_at).format('LT');
                    var nowtime = moment(message.created_at).format('LT');
                    if(lasttime != nowtime || message.job_id != last.job_id)
                        message.time = nowtime;                           

                } 

                if(message.job.jobable_type == 'project') {
                    
                    if(message.job.jobable.user_id == data.user_id) {
                        
                        message.title = 'Client';                                        
                    }                      
                    else
                        message.title = 'Project Manager';
                }                    

                if(message.job.jobable_type == 'group')
                    message.title = 'Controller';
                
                if(message.job.jobable_type == 'package')
                    message.title = 'Surveyor';
            
                return message;


        },
        scrollFunction() {          
			
           // if(!this.isProcessing)
            if ($('#chatroom-log').scrollTop() == 0){
               
                this.isProcessing = true;                
             
                var last_id = this.messages[0].id;
                let  _this = this;
                setTimeout( function() {
				axios.get('/api/messages/jobs/'+_this.job.id+'/last/'+last_id)
				 .then(({data})=>{
                     if(data.length > 0) {

                        var oldHeight = _this.$el.querySelector("#chatroom-log").scrollHeight;
                        data = _this.formatMessages(data, _this.$store.state.user.id);

                        var messages = data.concat(_this.messages);
                        _this.isProcessing = false;
                        _this.messages = messages; 
                        setTimeout(function() {
                            var el =  _this.$el.querySelector("#chatroom-log");
                            var newHeight = el.scrollHeight;                        
                            // el.scrollTop = (newHeight -oldHeight);
                            $(el).animate({scrollTop: (newHeight -oldHeight)}, 0);
                            el.animate(function(){el.scrollTop= (newHeight -oldHeight)}, 10, function(){
                                _this.show = true;
                            });
                        }, 1);
    
                     }
               
				 });
              }, 500);
              this.show = false;
				
			}
		}      

    }

}

</script>
<style >

#chat-list img {
    max-width: 300px;
    max-height: 150px;
}
</style>
