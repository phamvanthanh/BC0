<template>					<!-- User menu -->

	<div class="content-wrapper chat-page">

		<div class="page-header">
			<div class="page-header-content">
				<div class="page-title">
					 <span>{{$route.meta.display}}</span>
				</div>

				<div class="heading-elements">
					<div class="heading-btn-group">
						
					</div>
				</div>
			</div>

		
		</div>
	
		<div class="content">
			<div class="panel panel-flat no-border">		

				 <div class="panel-body ml30 mr30 no-border">

					<div class="chatnav col-md-4">
					
							<div class="chatnav-heading">
								<span>Job Groups</span>								
							</div>

							<div class="chatnav-room">
								<ul class="media-list media-list-linked">
									<li v-for="job in jobs" class="media">
										<a @click="activateJob(job)"  >
										
											<div class="media-body">
												<span class="fw-600">#{{job.id}} - {{job.name}}</span><span class="text-size-small text-muted">  </span>
												<span class="text-size-small text-muted display-block">Project {{job.project}}</span>
											</div>
											<div class="media-right media-middle">
												<span class="status-mark bg-success"></span>
											</div>
										</a>
									</li>
								</ul>
							</div>
						
					</div>
					<div class="chatroom col-md-8">
						<div class="chatroom-heading">							   
							<span v-if="active_job.id">
								
							<span class="display-block fw-600"> #{{active_job.id}} {{active_job.name}}</span>
							<span class="text-size-small text-muted "> Project {{active_job.project}}</span>
							
							</span>						
						</div>
						  <chatlog 
							:job="active_job"
						  ></chatlog>	
						<div class="chatroom-composer" v-if="active_job.id" >
							<form @submit.prevent="onSubmit"  method="post" >
								<div class="chat-composer" >
									<input class="msg-input"  name="message"  v-model="form.message"  rows="2" cols="1" placeholder="Enter your message...">
										<a class="chat-actions" @click="uploadFile" ><i class="icon-image4"></i></a>
										 	
									</input>
									<input name="fileUpload" @change="onFileChange" id="file-input" class="chat-actions hidden" type="file" >
								
									<button type="submit" class="btn btn-primary">Send</button>
								</div>
								<div class="row">
									<div class="col-xs-6">
										<ul class="icons-list icons-list-extended mt-10">
										</ul>
									</div>								
								</div>
							</form>
						</div>
					
					</div>
				</div>
			</div>
		</div>
		<!-- /content area -->

	</div>

</template>

<script>
import chatlog from './chatlog';
// import FileUpload from 'vue-simple-upload/dist/FileUpload';
export default {

	data() {
		return  {
			view: 'default',
			jobs: [],
			active_job: {
				id: null,
				name: null,
				relateds: []
			},

			form: new Form({
				job_id: null,
				message: null,
				user_id: this.$store.state.user.id
			}),

			

		}
	},

    components: {
        chatlog,
    },
    created() {
		this.getJobsByUser();
	},

	computed: {
		user() {
			return this.$store.state.user;
		}
	},


	methods: {
		 getJobsByUser() {
            axios.get('/api/jobs')
                 .then(({data})=>{
					//  console.log(data);
                     if(!hasRole(this.$store.state.user.roles, 'client') )
						this.jobs = data.map(function(e){
						
							return {
								id: e.job_id,
								name: e.info.jobable.name,
								jobable_type: e.info.jobable_type,
								project: e.info.project.name,
								from_date: e.info.from_date,
								to_date: e.info.to_date,
								relateds: e.relateds,
								status: e.info.status
							}
						});
					else //Case clients data is projects

						this.jobs = data.map(function(e){
							return {
								id: e.job.id,
								name: e.name,
								jobable_type: 'project',
								project: e.name,
								from_date: e.job.from_date,
								to_date: e.job.to_date,
								relateds: [e.job.id],
								status: e.job.status
							}
						});
					
				})
                 .catch((error)=>console.log(error))
        },
		activateJob(job) {
	
			this.active_job = job;
			
		},

		onSubmit() {
            this.form.job_id = this.active_job.id;
			this.form.user_id = this.$store.state.user.id;
            this.form.post('/api/messages')
                     .then(({data})=>{                       
                         bus.$emit('getmessages');
                     })
					 .catch((error)=>{

					 });
			this.form.message = null;
        },

		uploadFile() {
	
			$("#file-input").click();
		},
	 	onFileChange (e) {		
			let files = e.target.files || e.dataTransfer.files

			if (!files.length) {
			return
			};

			/*global FormData XMLHttpRequest:true*/
			/*eslint no-undef: "error"*/

			this.file = files[0]
			let formData = new FormData()
			formData.append('file', this.file)

			axios.post('/api/messages/files', formData)
				.then(({data})=>{
					this.form.message = '<img src="'+data.url+'" >';
					this.onSubmit();
					this.form.message = null;

				})
				.catch((error)=>{

				})     
      
        },

	

		
	}

}
</script>

<style>


.chat-composer {
    display: flex;
}
.chat-composer input {
    flex: 1 auto;
}
.chat-composer button {
    border-radius: 0;
}

.msg-composer {
	border: 1px solid #ccc;

	height: 30px;
}
.msg-input {
	/*border: none;*/
}
.msg-input {
	position: relative;
	/*background: transparent*/
}
.chat-actions {
	position:absolute;
	right: 60px;
	height: 100%;
	line-height: 30px;
}


</style>