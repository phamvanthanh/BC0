<template>
<div class="content-wrapper">
    <!-- Page header -->
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
                <h6><i class="icon-arrow-left15 position-left"></i><span class="text-semibold">Exception!</span></h6>
            </div>

            <div class="heading-elements">
                <div class="heading-btn-group">
                  
                   
                       
                </div>
            </div>
        </div>    
    </div>
    <!-- /page header -->


    <!-- Content area -->
    <div class="content">
        <!-- State saving -->
        <div class="panel panel-flat">
            <!--<div class="panel-heading">
              
                <div class="heading-elements">
                    
                </div>
            </div>-->
            
            <div class="panel-body">
              <h5> Resource not found </h5>
            </div>
            
         
         
        </div>
        <!-- /state saving -->				

        <!-- Footer -->
     
        <!-- /footer -->

    </div>
    <!-- /content area -->

</div>
</template>

<script>

 
</script>
