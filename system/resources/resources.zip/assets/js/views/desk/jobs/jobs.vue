<template>
<div class="content-wrapper">
    <!-- Page header -->
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
                <window-heading2></window-heading2>   
            </div>

            <div class="heading-elements">
               
            </div>
        </div>

    
    </div>

    <div class="content">

        <div class="panel panel-flat">
            <div class="panel-heading">
           
                <div class="heading-elements">
                    <div class="heading-btn">
                                                    
                    </div>
                </div>
            </div>        
            <div class="panel-body"> 
                <v-client-table 
                    :data="jobs" 
                    :columns="columns" 
                    :options="options">
                    <template slot="actions" scope="props">
                        <div>
                            <router-link :to="{name: 'desk.job', params: {id: props.row.id}}" ><i class="icon-unfold"></i></router-link>
                        </div>
                    </template>
                    <template slot="isAwarded" scope="props">  
                          <span :class="[props.row.isAwarded == 'Yes'? 'label-success': 'label-default', 'label' ]">{{props.row.isAwarded}}</span>
                       
                    </template>
                    <template slot="num_bids" scope="props">  
                           <span :class="[props.row.num_bids > 0? 'label-primary': 'label-default', 'label' ]">{{props.row.num_bids}}</span>
                    </template>
                </v-client-table>
                
            </div>
        </div>  
    </div>
</div>
</template>
<script>

import  ClientTable from 'vue-tables-2';
import {capitalize} from './../../../core/filters';


export default {
    data() {
        return {
            
            jobs:[],
            columns: ['id', 'name', 'jobable_type', 'project',  'from_date', 'to_date', 'num_bids', 'isAwarded', 'status', 'actions'],
            options: {
                headings: {
                    id: 'Id',
                    name: 'Name',
                    jobable_type: 'Type',
                    project: 'Project',
                    from_date: 'From',
                    to_date: 'To',
                    num_bids: 'Bids',
                    isAwarded: 'Awrd',
                    actions: ''
                    
                },
                templates: {        
                    status: 'status'                    
                },
                skin: 'table-hover',
                texts: {
                    filter: ''
                },
                columnsClasses: {
                    id: 'w-70',
                    name: 'column-expanded',
                    jobable_type: 'w-70',
                    project: 'w-150',
                    from_date: 'w-80',
                    to_date: 'w-80',
                    num_bids: 'w-50',
                    isAwarded: 'w-50',
                    progress: 'w-150',
                    status: 'w-70', 
                    actions: 'text-right w-40 action',
                      
                },
                sortIcon: { 
                    base: '',  up:'icon-arrow-up5', down:'icon-arrow-down5'

                },


            }          
            
            
        }
    },
    
    created() {
        let _this = this;
        this.getJobs();
        
    }, 

    methods: {   

        getJobs() {
            axios.get('/api/desk/works')
                    .then(({data})=>{
                        this.jobs = data.map(function(e){
                            return {
                                id: e.id,
                                name: e.info.jobable.name,
                                jobable_type: capitalize(e.jobable_type),
                                project: e.info.project.name,
                                from_date: moment(e.from_date).format('YY/MM/DD'),
                                to_date: moment(e.to_date).format('YY/MM/DD'),
                                num_bids: e.info.bids? e.info.bids.length: 0,
                                isAwarded: e.info.awarded? 'Yes': 'No',
                                status: e.status
                            }
                        });})
                    .catch((error)=>{
                        console.log(error);})
        },
        goBack() {
            router.go(-1);
        },
        forward() {
            router.go(1);
        }
        
    }
    
}
</script>