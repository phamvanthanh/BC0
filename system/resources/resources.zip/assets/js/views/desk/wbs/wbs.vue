<template>
<div class="content-wrapper">
  <div class="page-header">
      <div class="page-header-content">
          <div class="page-title">
              <window-heading2></window-heading2>
          </div>
          <div class="heading-elements">
          
          </div>
      </div>   
  </div>

  <div class="content">
    <div class="panel panel-flat" >
      <div class="panel-heading">	
      				
        <div class="heading-elements">
          <div class="heading-btn">
            <div class="form-group">             
                <div class="switch-box">												  
                    <label class="switch ">	
                        <span class="switch-label">Edit</span>																										
                        <input v-model="editMode" @click="toggleEditMode" type="checkbox"  >
                        
                        <div class="slider"></div>
                    </label>
                </div>             
            </div>								
          </div>
          
        </div>					
      </div>
    
      <div class="panel-body" >                 
          <div class="tree-default">
            <ul id="wbs-ul"  class="ui-wbstree">							
              <wbs		
                :node="wbs"
                :editMode="editMode"
                :isNewEntry="isNewEntry" >									
              </wbs>               
            </ul>
          </div>			
      </div>
  
    </div>	
  </div>
</div>  
</template>
<script>

import wbs from './wbsnode';

export default {
 
    data() {
        return {
         
            editMode: (localStorage.getItem('wbseditmode') == "false"? false: true) ,
            wbs:[],
            isNewEntry: false,
            currentActive: {},
           
        }
    },
    created() {
      
        let _this = this;
        this.getWbs();

        bus.$on('newentry', function(e){
          _this.isNewEntry = e;
        });

        bus.$on('refreshwbs', function(){       
          _this.getWbs();
          
        });
    },
   
    computed: {
        notifications() {
            return this.$store.state.notifications
        },
        
    },
    components: {
        wbs
    },
    methods: {
      toggleEditMode: function(){      
        localStorage.setItem('wbseditmode', this.editMode)          
      },      
          
      getWbs: function() {
        axios.get('/api/desk/wbs')
             .then(({data})=>{this.wbs = data});
      },  
            
      removePwbs: function(){
         this.form.codes = this.removecodes;   
         this.form.post('/api/desk/pwbs/delete')
                  .then(({data}) => {         
                    this.getPwbs(this.id);           
                    var i, index;       
                    for(i=0; i < this.removecodes.length; i++) {                      
                      index = this.disabledcodes.indexOf(this.removecodes[i]);
                      if( index >= 0)
                        this.disabledcodes.splice(index, 1);                     
                    }
                    this.removecodes = [];
                   })                 
                  .catch((errors) =>{
                    console.log(errors); })
                 
      },
      goBack() {
        router.go(-1);
      },
      forward() {
        router.go(1);
      }
    }
}

  

</script>


