<template id="wbs-template"> 
    <li > 							
        <span v-bind:class="{ 'fancytree-warnning': isActive }" class="fancytree-node fancytree-expanded "  >
            <span :class="{bold: isFolder}"  class="fancytree-expander"
                @click="toggle" v-if="isFolder">[{{open ? '-' : '+'}}]
            </span>
            <span @click="clickNode"  @dblclick="changeType" class="fancytree-title">
                 {{node.code+ ' - '+node.name}}
            </span>	   

            <span v-if="editMode"  class="bg-warning fancytree-item" @click="deleteNode" ><i v-if="isActive" class="icon-cross3" > </i></span></span>														
        </span>
        <ul v-show="open" v-if="isFolder">
            <wbs
                class = "wbs"
                v-for = "node in node.children" v-bind:key="node.code"
                :node = "node"
                :editMode = "editMode"
                :isNewEntry = "isNewEntry" >
            </wbs>
            <li v-if="editMode" >
                <span v-if="edit">
                    <form method="post" @submit.prevent="onSubmit" @change="form.errors.clear($event.target.name)"  >                   
                        <input  type="text" name="code" v-model="form.code" placeholder="code"  style="width: 60px"> 
                        <input  type="text" name="name" v-model="form.name" placeholder="name"  style="width: 160px">	
              									
                        <button type="submit"  name="submit" :disabled="form.errors.any()" >Save</button>
                        <button @click="cancel" type="button">Canc</button>
                    </form>										
                </span>
                <span v-else @click="addChild" class="add" >+</span>
            </li>								
        </ul>
    </li>
</template>
<script>
import treemixin from './../../elements/treemixin';
let current = null;
export default {
    mixins: [treemixin],
    name: 'wbs',
    props: {
        editMode: false,
        isNewEntry: false
    },

    data() {
        return {
            edit: false,
            isActive: false, 
            form: new Form({
                code: null,
                parent_code: this.node.code,  
                name: null,
            })        
        }
    },
    created() {
       // this.disable();  
    },
   

    methods: {
        changeType() {      
          if (!this.isFolder) {
            Vue.set(this.node, 'children', [])
            this.addChild()
            this.open = true
          }
          
        },
        cancel() {   
             
          if(this.isNewEntry){              
            this.edit = false;
            if(Object.keys(this.node.children).length == 0)
                Vue.delete(this.node, 'children');
            bus.$emit('newentry', false);
          }
        },
        selectNode(){
           if(current)
            current.isActive = false;
           this.isActive = true; 
           current = this;
         
        
        },
        deleteNode() {
            this.form.code = this.node.code;
            this.form.post('/api/desk/wbs/delete')
                .then(({data})=>{             
                    bus.$emit('refreshwbs');})
                .catch((error)=>{console.log(error)})

        },
        deselectNode() { 
            
           this.isActive = false;            
        },  
        addChild(){
            
          if(!this.isNewEntry){  
            this.edit = true;       
            bus.$emit('newentry', true);
          }
        },  
        onSubmit() {
            this.form.post('/api/desk/wbs')
                .then(({data})=>{
                    bus.$emit('newentry', false);
                    bus.$emit('refreshwbs');
                    this.edit = false;
                    })
                .catch((error)=>console.log(error))

        }  
      
    }
}

</script>