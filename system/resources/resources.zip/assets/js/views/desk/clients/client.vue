 <template>
    <div class="content-wrapper">
        <div class="page-header">
            <div class="page-header-content">
                <div class="page-title">
                  <window-heading></window-heading>                  
                </div>

                <div class="heading-elements">
                    <div class="heading-btn-group" >
                        <router-link :to="{name:'desk.client.info'}" class="btn btn-link btn-float has-text"><i class="icon-info22 text-primary"></i><span>Info</span></router-link> 
                        <router-link :to="{name:'desk.client.projects'}" class="btn btn-link btn-float has-text"><i class="icon-tree5 text-primary"></i><span>Projects</span></router-link> 

                    </div>
                
                
                </div>
            </div>   
        </div>

        <div class="content">
             
           <router-view :client="client"></router-view>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {    
                uid: this.$route.params.uid,           
                client:{},               
            }
        },
      
        created() {           
            this.getClient(this.uid);           
        },     
   
        methods: {   
  
            getClient(uid) {
                axios.get('/api/desk/clients/'+uid)
                     .then(({data})=>{
                        this.client = data;
                        this.$store.commit('loadItem', {label: 'Client', name: data.first_name+' '+data.last_name});

                        })
                     .catch((error)=>{
                         console.log(error);})
            },           
          
        }
      
    }
</script>