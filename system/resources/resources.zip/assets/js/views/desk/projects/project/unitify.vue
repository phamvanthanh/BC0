<template  >
<div class="content-wrapper">
    <!-- Page header -->
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
                <h6><i class="icon-arrow-left52 position-left"></i><span >Projects</span></h6>
            </div>

            <div class="heading-elements">
                <div class="heading-btn-group" >
                   <submenu :pid="pid"></submenu>
                   
                </div>
            </div>
        </div>

    
    </div>
    <!-- /page header -->


    <!-- Content area -->
    <div class="content">
        <!-- State saving -->
        <div class="panel panel-flat">
            <div class="panel-heading">
                <h6 class="panel-title">Unitify</h6>
                <div class="heading-elements">
                    <ul class="icons-list">
                       
                       
                    </ul>
                </div>
            </div>
          
            <div class="panel-body">
                <div  class="wrapper">
                    <HotTable :root="root" 
                                :settings="hotSettings"
                                :data="leaves" >
                    </HotTable>
                </div>
                 
            </div>
           
           
         
        </div>
        <!-- /state saving -->				

        <!-- Footer -->
           <notify :warns="notifications"></notify>
        <!-- /footer -->

    </div>
    <!-- /content area -->

</div>
</template>

<script>
   
import notify from './../../core/Notify';
import submenu from './../elements/submenues/project';
import projectform from './../elements/projectform';

  import moment from 'moment';
  import numbro from 'numbro';
  import pikaday from 'pikaday';
  import Zeroclipboard from 'zeroclipboard';
  import Handsontable from 'handsontable';
  import HotTable from 'vue-handsontable-official';

    
    export default {
        data() {
              
            return {
                pid: this.$route.params.pid,
               
                leaves:  null,
                root: 'unitify',
                hotSettings: {
                  startCols: 3,           
                  rowHeaders: true,
                  columns: [
                         
                          {data: 'code', readOnly: true},
                          {data: 'name', readOnly: true},
                          {data: 'unit', type: 'dropdown',                              
                              source: ['m', 'm2', 'm3', 'kg', 'ton', 'ea', 'set', 'lot'],
                              strict: true,
                              allowInvalid: false
                          }
                       
                  ],
                  colHeaders: ['Code', 'Name', 'Unit'],
                  stretchH: 'all',
                  afterChange: function(change, source) {
                      if(source == 'edit') {
                          var change = change[0], data;             
                          var row  = this.getSourceDataAtRow(change[0]);
                          if(change[2] != row.unit){
                              data = {
                                  project_id: row.project_id,
                                  code      : row.code,
                                  unit      : row.unit
                              }
                              axios.post('/projects/'+row.project_id+'/pwbs/unitify', data)
                                    .then(({data}))
                                    .catch((error)=>console.log(error))
                              
                          }
                           

                      }
                      
                  }
                }
            }          
        
        },
        created() {
            axios.get('/projects/'+this.pid+'/pwbs/leaves')
                 .then(({data})=>{        
                   this.leaves = data;
                  })
                 .catch((error)=>{
                   console.log(error)})    

        },       
            
        computed: {
            notifications() {
                return this.$store.state.notifications
            },            
        },
       
        components: {          
            notify,
            projectform,
            submenu,
            HotTable                   
           
                      
        },
        methods: {
            submit(data) {
                console.log(data);
            }
        }
      
    }
</script>


<style>
  #unitify {
    width: 100%;
    height: 400px;
    overflow: hidden;
  }
</style>


