<template  >
<div class="content-wrapper">
    <!-- Page header -->
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
                <window-heading2></window-heading2>               
            </div>

            <div class="heading-elements">
                <div class="heading-btn-group" >
                     <router-link :to="{name:'desk.project.info', params: {pid: id}}" class="btn btn-link btn-float has-text"><i class=" icon-info22 text-primary"></i><span>Info</span></router-link> 
                     <router-link :to="{name:'desk.project.pwbs', params: {pid: id}}" class="btn btn-link btn-float has-text"><i class="icon-tree5 text-primary"></i><span>Pwbs</span></router-link> 
                     <router-link :to="{name:'desk.project.files', params: {pid: id}}" class="btn btn-link btn-float has-text"><i class="icon-files-empty text-primary"></i><span>Files</span></router-link>
                     <router-link :to="{name:'desk.project.links', params: {pid: id}}" class="btn btn-link btn-float has-text"><i class="icon-link text-primary"></i><span>Links</span></router-link>                    
                     <router-link :to="{name:'desk.project.sections', params: {pid: id}}" class="btn btn-link btn-float has-text"><i class="icon-git-branch text-primary"></i><span>S&P</span></router-link>                    
                     <router-link :to="{name:'desk.project.reports', params: {pid: id}}" class="btn btn-link btn-float has-text"><i class="icon-statistics text-primary"></i><span>Reports</span></router-link>
                     <router-link :to="{name:'desk.project.quantity', params: {pid: id}}" class="btn btn-link btn-float has-text"><i class="icon-statistics text-primary"></i><span>Quantity</span></router-link>
                     
                </div>
            </div>
        </div>

    
    </div>
    <!-- /page header -->

    <!-- Content area -->
    <div class="content">
        <router-view 
            :id="id"
            :job="project">
        </router-view>   
        <notify :warns="$store.state.notifications"></notify>
    </div>
     

</div>
</template>

<script>
  import notify from './../../../core/Notify';

    export default {
        data() {
            return {
                 id : this.$route.params.pid,
                 project: null,
            }
        },   
       
        components: {   
            notify,            
                      
        },
        created() {
            this.getProject();
        },
        methods: {
       
            getProject() {
                 axios.get('/api/projects/'+this.id)
                .then(({data})=> {
                    
                    this.$store.commit('loadItem', {label:'Project', name: data.name});
                    this.project = data.job;
                });

            }
        }
      
    }
</script>
