<!-- Footer -->
<div class="footer text-muted text-center">
	&copy; 2017. <span >QsCompanion</span> 
</div>
<!-- /footer -->
