	<!-- Main navbar -->
	<div class="navbar navbar-inverse">
      
            <div class="navbar-header">
                <a class="navbar-brand" href="/"><img src="/portals/ico/logo.png" alt=""></a>

                <ul class="nav navbar-nav navbar-right visible-xs-block">
                    <li>
                        <a class="muted" href="tel:+84-463-288-901" >
                        <i class="icon-phone2"></i>
                            <span class="position-right"> +84-463-288-901</span>
                        </a>
                    </li>
                </ul>
            </div>
          
            <div class="navbar-right hidden-xs" id="navbar-mobile">
                <ul class="nav navbar-nav navbar-right ">
                    <li>               
                        <a class="muted" href="tel:+84-463-288-901" >
                            <i class="icon-phone2"></i>
                            <span class="position-right"> +84-463-288-901</span>
                        </a>				
                    </li>

                    
                </ul>
            </div>
            
        
	</div>
	<!-- /main navbar -->



