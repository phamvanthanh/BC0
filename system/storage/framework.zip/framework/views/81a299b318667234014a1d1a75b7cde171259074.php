<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="/js/extensions/pages/pwbs.js"></script>
<div class="content-wrapper">
    <!-- Page header -->
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold">Projects</span></h4>
            </div>

            <div class="heading-elements">
                <div class="heading-btn-group">
                    <a href="/projects/new" class="btn btn-link btn-float has-text"><i class="icon-add text-primary"></i><span>New project</span></a>
   
                </div>
            </div>
        </div>

    
    </div>
    <!-- /page header -->


    <!-- Content area -->
    <div class="content">
        <!-- State saving -->
        <div class="panel panel-flat">
            <div class="panel-heading">
                <h5 class="panel-title">Projects</h5>
                <div class="heading-elements">
                    <ul class="icons-list">
                        <li><a data-action="collapse"></a></li>
                        <li><a data-action="reload"></a></li>
                        <li><a data-action="close"></a></li>
                    </ul>
                </div>
            </div>
            <!--
            <div class="panel-body">

            </div>
            -->
            <table class="table datatable-save-state">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Jid</th>                                  
                        <th>Name</th>
                        <th>Client</th>
                        <th>Nation</th>
                        <th>Ind</th>
                        <th>Deadline</th>
                        <th>Created</th>
                        <th>Status</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($project['id']); ?></td>
                        <td><?php echo e($project['jid']); ?></td>
                        <td><a href="<?php echo e(url('/projects',$project['id'])); ?>"><?php echo e($project['name']); ?></a></td>
                        <td><?php echo e($project->user->first_name); ?> <?php echo e($project->user->last_name); ?></td>
                        <td><?php echo e($project->nation->name); ?></td>
                        <td><?php echo e($project->industry->name); ?></td>
                        <td><?php echo e($project['to_date']); ?></td>
                        <td><?php echo e($project['created_at']); ?></td>                           
                        <td><span class="label label-success"></span><?php echo e($project['status']); ?></td>

                        <td class="text-center">
                            <ul class="icons-list">
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="icon-menu9"></i>
                                    </a>
                                    <!--- Role base dropdown menue -->
                                    <ul class="dropdown-menu dropdown-menu-right">                                                                             
                                        <li><a href="<?php echo e(url('/projects', $project['id'])); ?>"><i class="icon-file-word"></i>Edit</a></li>
                                        <li><a href="<?php echo e(url('/project-wizard', $project['id'])); ?>"><i class="icon-file-pdf"></i>Project wizard</a></li>                                          
                                        <li><a href="#"><i class="icon-file-excel"></i>Doc. link</a></li>					
                                        <li><a href="#"><i class="icon-file-excel"></i>Files</a></li>
                                        <li><a href="#"><i class="icon-file-excel"></i>Pwbs</a></li>
                                        <li><a href="#"><i class="icon-file-word"></i>Reports</a></li>
                                        <li><a href="#"><i class="icon-file-word"></i>Payment</a></li>
                                        <li><a href="#"><i class="icon-file-excel"></i>Quotation</a></li>
                                        
                                    </ul>
                                    <!---/Role base dropdown menue -->
                                </li>
                            </ul>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
        <!-- /state saving -->				

        <!-- Footer -->
        <?php $__env->startSection('footer'); ?>
            ##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f##
        <?php echo $__env->yieldSection(); ?>
        <!-- /footer -->

    </div>
    <!-- /content area -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('core.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>