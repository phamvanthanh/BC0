<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Page header -->
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
               <ul class="breadcrumb position-right">
                    <li><a href="/projects">Projects</a></li>			
                    <li ><a href="/projects" >#{id}</a></li>
                    <li class="active">Schedule</li>
                </ul>
            </div>

            <div class="heading-elements">
                <div class="heading-btn-group">
                    <a href="/projects/id" class="btn btn-link btn-float has-text"><i class="icon-bars-alt text-primary"></i><span>Overview</span></a>
					<a href="/projects/id/schedule" class="btn btn-link btn-float has-text"><i class="icon-calculator text-primary"></i> <span>Schedule</span></a>
					<a href="/projects/id/pwbs" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Pwbs</span></a>
                    <a href="/projects/id/reports" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Reports</span></a>
                    <a href="/projects/id/markdowns" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Markdowns</span></a>
                    <a href="/projects/id/files" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Files</span></a>
                </div>
            </div>

            
        </div>

    </div>
    <!-- /page header -->


    <!-- Content area -->
    <div class="content">
        <!-- State saving -->
        <div class="panel panel-flat">
            <div class="panel-heading">
                <h5 class="panel-title">Files</h5>
                <div class="heading-elements">
                    <ul class="icons-list">
                        <li><a data-action="collapse"></a></li>
                        <li><a data-action="reload"></a></li>
                        <li><a data-action="close"></a></li>
                    </ul>
                </div>
            </div>
          
            <div class="panel-body">

            </div>
      
            
               
        </div>
        <!-- /state saving -->				

    

    </div>
    <!-- /content area -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('core.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>