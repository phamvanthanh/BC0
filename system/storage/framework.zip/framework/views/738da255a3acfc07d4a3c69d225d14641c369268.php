<?php $__env->startSection('content'); ?>
<!-- Main content -->
	<!-- Core JS files -->


	<!-- /core JS files -->

	<!-- Theme JS files -->


    
<div class="content-wrapper" id="app" >

	<!-- Page header -->
	<div class="page-header">
		<div class="page-header-content">
			<div class="page-title">
	
				<ul class="breadcrumb position-right">
					<li><a href="/projects"><h5>Projects</h5></a></li>			
					<li id="index" class="active" data-pid="<?php echo e($pid); ?>" >#<?php echo e($pid); ?></li>
				</ul>
			
			</div>
			<div class="heading-elements">
				<div class="heading-btn-group">
                    <?php echo $__env->make('pages.projects.includes.sub-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>					
		</div>
	</div>
	<!-- /page header -->
	<!-- Content area -->
    <div class="content" >
        
            <!-- Project -->
            <div class="row" >
                <div class="col-lg-12" >
                    <!-- Task overview -->
                    <div class="panel panel-flat" >
                        <div class="panel-heading">
                            <h5 class="panel-title"></h5>
                            						
                        </div>

                        <div class="panel-body" >
                            <form  method="post"   @submit.prevent="submit"  form="information_form">
                                <?php echo e(method_field('post')); ?>

                                <?php echo e(csrf_field()); ?>

                                <div class="row">
                                    
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Name: <span class="text-danger">*</span></label>
                                            <input type="text" v-model="project.name" value="" class="form-control required" >
                                        </div>
                                            
                                    </div>
                                    <div class="col-md-4 ">
                                        <div class="form-group">
                                            <label>Client: <span class="text-danger">*</span></label>
                                            <select type="text" v-model="project.user_id" class="form-control required" >
                                                <option></option>
                                                <option v-for="client in clients" v-bind:value="client.id" >{{client.id +' | '+ client.first_name+' '+client.last_name}}</option>
                                            </select>
                                        </div>														
                                    </div>         

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Nation: <span class="text-danger">*</span></label>
                                            <select v-model="project.nation_id"   class="form-control required">
                                                <option></option>                                    
                                                <option value="1">United States</option>
                                                <option value="2">Canada</option>                                        

                                                <option value="3">Chile</option>
                                                <option value="4">Argentina</option>
                                                <option value="5">Colombia</option>
                                                <option value="6">Peru</option>                                        

                                                <option value="8">Croatia</option>
                                                <option value="9">Hungary</option>
                                                <option value="10">Ukraine</option>                            

                                
                                                <option value="21">Egypt</option>
                                                <option value="22">Israel</option>
                                                <option value="23">Nigeria</option>
                                                <option value="24">United Arab Emirates</option>                                     

                                        
                                                <option value="26">Australia</option>
                                                <option value="27">China</option>
                                                <option value="28">India</option>
                                                <option value="29">Singapore</option>
                                            
                                            </select>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Industry: <span class="text-danger">*</span></label>
                                            <select type="text" v-model="project.industry_id"  class="form-control required">
                                                    <option > </option> 
                                                    <option value="1">Residential and commercial buildings</option> 
                                                    <option value="2">Industrial and power plant</option> 
                                                    <option value="3">Road and bridge</option> 
                                                    <option value="4">Small and private home</option> 
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>From: </label>
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-calendar22"></i></span>
                                                <input type="date" v-model="project.from_date"  class="form-control daterange-single required" value="">
                                                
                                            </div>
                                        </div>
                                    </div>	
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>To: </label>
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-calendar22"></i></span>
                                                <input type="date" v-model="project.to_date" class="form-control daterange-basic" value="">
                                                
                                            </div>
                                        </div>
                                    </div>								
                                </div>								
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Project overview:</label>                                            
                                            <textarea type="text" v-model="project.summary"   rows="5" placeholder="Short description about the project" value="" class="form-control"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Requirement:</label>
                                            <textarea type="text" v-model="project.requirement"  rows="5" placeholder="Descriptive requirement"  value="" class="form-control"></textarea>
                                        </div>
                                    </div>										
                                </div> 
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Status:</label> 
                                            <label class="radio-inline"><input type="radio" value="0" v-model="project.status" checked >Stand</label>
                                            <label class="radio-inline"><input type="radio" value="1" v-model="project.status">Ini</label>
                                            <label class="radio-inline"><input type="radio" value="2" v-model="project.status">Pricing</label>
                                            <label class="radio-inline"><input type="radio" value="3" v-model="project.status">Contract</label>                                           
                                            <label class="radio-inline"><input type="radio" value="4" v-model="project.status">Closed</label> 
                                        </div>
                                    </div>                                   									
                                </div> 
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                                                        
                                            <button type="submit" class="btn btn-primary">Save</button>
                                        </div>
                                    </div>
                                                                            
                                </div>     
                            </form>	
                        </div>   
                    </div>
                    <!-- /task overview -->		

                </div>

            
            </div>
            <!-- /Project -->


            <!-- Footer -->

            <!-- /footer -->

        </div>
        <!-- /content area -->
</div>
<!--/Content area -->
<!--Template area -->


<!--/Template-->


<script type="text/javascript" src="/js/extensions/pages/edit_project.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('core.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>