<a href="/projects/<?php echo e($pid); ?>" class="btn btn-link btn-float has-text"><i class="icon-bars-alt text-primary"></i><span>Overview</span></a>
<a href="/projects/<?php echo e($pid); ?>/schedule" class="btn btn-link btn-float has-text"><i class="icon-calculator text-primary"></i> <span>Schedule</span></a>
<a href="/projects/<?php echo e($pid); ?>/pwbs" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Pwbs</span></a>
<a href="/projects/<?php echo e($pid); ?>/groups" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Groups</span></a>
<a href="/projects/<?php echo e($pid); ?>/packages" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Packages</span></a>
<a href="/projects/<?php echo e($pid); ?>/reports" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Reports</span></a>
<a href="/projects/<?php echo e($pid); ?>/markdowns" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Markdowns</span></a>
<a href="/projects/<?php echo e($pid); ?>/files" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Files</span></a>