<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="/css/extensions/switch.css"></link>

<style>
.box {
	height: 450px;
	overflow-y: auto;
}
</style>


<!-- Main content -->
<div class="content-wrapper"  >

	<!-- Page header -->
	<div class="page-header">
		<div class="page-header-content">
			<div class="page-title">
				 <ul class="breadcrumb position-right">
                    <li><a href="/projects">Projects</a></li>			
                    <li id="index" data-pid="<?php echo e($pid); ?>" ><a href="/projects/<?php echo e($pid); ?>" >#<?php echo e($pid); ?></a></li>
                    <li class="active">Pwbs</li>
                </ul>			
			</div>
			<div class="heading-elements">
				<div class="heading-btn-group">
				    <?php echo $__env->make('pages.projects.includes.sub-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			   </div>
			</div>							
		</div>
	</div>
	<!-- /page header -->
	<!-- Content area -->

	<div class="content"  id="app"> 

		<!-- Project -->
		<div class="row" >
			<div class="col-lg-12" >
				<!-- Task overview -->
				<div class="panel panel-flat" >
					<div class="panel-heading">
						
						<div class="heading-elements">
							<div class="heading-btn">
								<div class="form-group">
									<div class="row">								
										<div class="col-sm-12">
											<div class="form-group no-margin-bottom">
												<div class="switch-box">												  
														<label class="switch ">	
															<span class="switch-label">Edit</span>																										
															<input v-model="edit" type="checkbox" name="edit">
															<div class="slider"></div>
														</label>
												</div>
												<div class="switch-box">													
														<label class="switch">
															<span class="switch-label">Wbs</span>
															<input type="checkbox" v-model="isShowWbs" >
															<div class="slider"></div>
														</label>	
												</div>
												
												
											</div>
										</div>								
									 </div>
								</div>								
							</div>
							
						</div>					
					</div>
					<!-- Vue Templates -->


					<!--/Vue Templates-->
					<!--Vue Scope -->
					<div class="panel-body"  id="pwbs"  >						
						<div class="row">
							
						</div>
						<!--Pwbs-static -->
						<div v-show="!edit" id="pwbs-static" class="row">
							<div  class="col-md-12">
								<div class="box">
									<ul id="pwbs-static-ul">							
										<pwbs
											class="pwbs"
											:node="pwbs"  >
										</pwbs>
									</ul>	
								</div>
							</div>
						</div>

						<!--/Pwbs-static -->

						<!--Pwbs-edit-->
						<div v-show="edit" id="pwbs-edit" class="bootstrap-duallistbox-container row" >
							<div  class="col-md-6" v-if="isShowWbs">
								<div class="btn-group btn-group-justified">
									<div class="btn-group">
										<span   class="btn  btn-default"> 
											Wbs
										</span>									
									</div>
									<div class="btn-group">
										<button @click='reset("wbs")' type="button" class="btn  btn-default"> 
											<i class="icon-reset"></i>
										</button>
									</div>
									<div class="btn-group">
										<button @click="passPwbs" type="button" class="btn btn-default"> 
											<i class="icon-circle-right2"></i>
										</button>
									</div>
								</div>
								<div class="box tree-default well border-left-info border-left-lg">
									<ul id="wbs-ul"  class="ui-fancytree fancytree-container fancytree-plain">							
										<wbs 
											class="wbs" 
											:node="wbs"
											:addcodes="addcodes"
											:disabledcodes="disabledcodes" 											
											>
										</wbs>
									</ul>
								</div>
							</div>
							<div v-bind:class="{'col-md-6': isShowWbs, 'col-md-12': !isShowWbs}">
								<div class="btn-group btn-group-justified">
									<div class="btn-group">
										<button @click="removePwbs" type="button" class="btn btn-default">
											<i class="icon-circle-left2"></i>
										</button>
									 </div>
									 <div class="btn-group">
										<button @click='reset("pwbs")' type="button" class="btn  btn-default"> 
											<i class="icon-reset"></i>
										</button>									
									</div>
									<div class="btn-group">
										<span   class="btn  btn-default"> 
											Pwbs
										</span>									
									</div>
								</div>								
							    <div class="box tree-default well border-left-info border-left-lg">
									<ul id="pwbs-edit-ul" class="ui-fancytree fancytree-container fancytree-plain" >							
										<epwbs 
											class="pwbs"
											:node="pwbs"
											:removecodes="removecodes"
											:edit="edit">
										</epwbs>
									</ul>
								</div>
							</div>
						</div>				
						<!--/Pwbs-edit -->					
					</div>
					<!--/Vue Scope -->
				</div>		
			</div>
		</div>


		<!-- Footer -->
			<?php echo $__env->make('core.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- /footer -->

	</div>
	<!-- /content area -->
	<!--Templates-->
						<template id="pwbs-template">
							<li>
								<div  class="list-group-item">
									<span :class="{bold: isFolder}" class="fancytree-expander"
										@click="toggle" v-if="isFolder">[{{open ? '-' : '+'}}]
									</span>					
									<span > 
										{{node.code+ ' - '+node.name}}
									</span>
								</div>
								<ul v-show="open" v-if="isFolder">
									<pwbs
										class="spwbs"
										v-for="node in node.children" v-bind:key="node.code"
										:node="node" >
									</pwbs>								
								</ul>
							</li>
						</template>
						<template id="epwbs-template">
							<li><span  v-bind:class="{'fancytree-warnning': isActive  }" class="fancytree-node fancytree-expanded" >
									<span :class="{bold: isFolder}" class="fancytree-expander"
											@click="toggle" v-if="isFolder">[{{open ? '-' : '+'}}]
									</span>	
									<span  @click="clickNode" @dblclick="changeType"  class="fancytree-title" >										
											{{node.code+ ' - '+node.name}}							
									</span>
									<span v-if="node.extension == 1" class="label bg-info-300">
										ex
									</span>
								</span>
							
								<ul v-show="open" v-if="isFolder">
									<epwbs
										class="epwbs"
										v-for="node in node.children" v-bind:key="node.code"
										:node="node" 
										:removecodes="removecodes">
									</epwbs>
									<slot name="addchild" > </slot>
									<li >
										<span v-if="isNewEntry">
											<form method="post" @submit.prevent="submit" >
												<?php echo e(method_field('post')); ?>

												<?php echo e(csrf_field()); ?>

												<input type="text" v-model="code" placeholder="code" required style="width: 60px"> 
												<input type="text" v-model="name" placeholder="name" required style="width: 160px">	
												<input type="checkbox" v-model="quantify">Quantify										
												<button type="submit">Save</button>
												<button @click="cancel" type="button">Canc</button>
											</form>										
										</span>
										<span v-else @click="addChild" class="add"  >+</span>
									</li>
								</ul>
							</li>
						</template>			
						<template id="wbs-template"> 
							<li > 							
								<span v-bind:class="{ 'fancytree-active': isActive, 'fancytree-selected': isDisabled }" class="fancytree-node fancytree-expanded "  >
									<span :class="{bold: isFolder}"  class="fancytree-expander"
										@click="toggle" v-if="isFolder">[{{open ? '-' : '+'}}]
									</span>
									<span @click="clickNode" class="fancytree-title">
										{{node.code+ ' - '+node.name}}
									</span>															
								</span>
								<ul v-show="open" v-if="isFolder">
									<wbs
										class="wbs"
										v-for="node in node.children" v-bind:key="node.code"
										:node="node"
										:addcodes="addcodes"
										:disabledcodes="disabledcodes" >
									</wbs>								
								</ul>
							</li>
						</template>
	<!--/Templates-->

</div>
<script type="text/javascript" src="/js/extensions/pages/pwbs.js"></script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('core.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>