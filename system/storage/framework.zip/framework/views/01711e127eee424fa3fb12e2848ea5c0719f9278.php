<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Page header -->
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold">Users</span></h4>
            </div>

            <div class="heading-elements">
                <div class="heading-btn-group">
                    <a href="/users/new" class="btn btn-link btn-float has-text"><i class="icon-add text-primary"></i><span>New</span></a>
                       
                </div>
            </div>
        </div>    
    </div>
    <!-- /page header -->


    <!-- Content area -->
    <div class="content">
        <!-- State saving -->
        <div class="panel panel-flat">
            <div class="panel-heading">
                <h5 class="panel-title">Users</h5>
                <div class="heading-elements">
                    <ul class="icons-list">
                        <li><a data-action="collapse"></a></li>
                        <li><a data-action="reload"></a></li>
                        <li><a data-action="close"></a></li>
                    </ul>
                </div>
            </div>
            <!--
            <div class="panel-body">

            </div>
            -->
            <table class="table table-responsive datatable-save-state">
                <thead>
                    <tr>
     
                        <th>uid</th>                                  
                        <th>Name</th>
                        
                        <th>Email</th>
                        <th>Phone</th>                       
                        <th>Organization</th>
                        <th>Nation</th>
                        <th>Status</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
              
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                        <td><?php echo e($user['id']); ?></td>                        
                        <td><?php echo e($user['first_name']); ?> <?php echo e($user['last_name']); ?></td>                     
                        <td><?php echo e($user['email']); ?></td>
                        <td><?php echo e($user['phone']); ?></td>                      
                        <td><?php echo e($user['organization']); ?></td> 
                        <td><?php echo e($user->nation->name); ?></td>                          
                        <td><span class="label label-success"></span><?php echo e($user['status']); ?></td>

                        <td class="text-center">
                            <ul class="icons-list">
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="icon-menu9"></i>
                                    </a>
                                    <!--- Role base dropdown menue -->
                                    <ul class="dropdown-menu dropdown-menu-right">
                                        <li><a href="<?php echo e(url('/users', $user['id'])); ?>"><i class="icon-file-pdf"></i>edit</a></li>
                                        <li><a href="<?php echo e(url('/users', $user['id'], 'role')); ?>"><i class="icon-file-pdf"></i>Roles</a></li>                                      
                              
                                    </ul>
                                    <!---/Role base dropdown menue -->
                                </li>
                            </ul>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
        <!-- /state saving -->				

        <!-- Footer -->
        <?php $__env->startSection('footer'); ?>
            ##parent-placeholder-d7eb6b340a11a367a1bec55e4a421d949214759f##
        <?php echo $__env->yieldSection(); ?>
        <!-- /footer -->

    </div>
    <!-- /content area -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('core.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>