<?php $__env->startSection('content'); ?>
<!-- Main content -->
<script type="text/javascript" src="/js/extensions/pages/form_layouts.js"></script>

<div class="content-wrapper">

	<!-- Page header -->
	<div class="page-header">
		<div class="page-header-content">
			<div class="page-title">
	
				<ul class="breadcrumb position-right">
					<li><a href="/users"><h5>Users</h5></a></li>			
					<li class="active">#<?php echo e(isset($user->id) ? $user->id : '#new'); ?></li>
				</ul>
			
			</div>
			<div class="heading-elements">
				<div class="heading-btn-group">
				
				</div>
			</div>					
		</div>
	</div>
	<!-- /page header -->
	<!-- Content area -->
	<div class="content" >

		<!-- Project -->
		<div class="row" >
			<div class="col-lg-12" >
				<!-- Task overview -->
				<div class="panel panel-flat" >
					<div class="panel-heading mt-5">
						<h5 class="panel-title"></h5>						
					</div>

					<div class="panel-body" >
						 <form class="form-horizontal" method="post" action="/users/<?php echo e(isset($user->id) ? $user->id : old('store')); ?>'">
                            <div class="col-md-6">
                                <fieldset>
                                    <legend class="text-semibold"><i class="icon-user-plus position-left"></i>User details</legend>
                                             <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label class="col-lg-3 control-label">Your name:</label>
                                        <div class="col-lg-9">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <input name="first_name" value="<?php echo e(isset($user->first_name) ? $user->first_name : old('first_name')); ?>" type="text" placeholder="First name" class="form-control required">
                                                </div>

                                                <div class="col-md-6"> 
                                                    <input name="last_name"  value="<?php echo e(isset($user->last_name) ? $user->last_name : old('last_name')); ?>" type="text" placeholder="Last name" class="form-control required">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-3 control-label">Email:</label>
                                        <div class="col-lg-9">
                                            <input name="email" value="<?php echo e(isset($user->email) ? $user->email : old('email')); ?>" type="email" placeholder="eg.: your@realemail.com" class="form-control required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-3 control-label">Phone #:</label>
                                        <div class="col-lg-9">
                                            <input name="phone" value="<?php echo e(isset($user->phone) ? $user->phone : old('phone')); ?>" type="text" placeholder="+99-99-9999-9999" class="form-control required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-3 control-label">Organization:</label>
                                        <div class="col-lg-9">
                                            <input name="organization" value="<?php echo e(isset($user->organization) ? $user->organization : old('organization')); ?>" type="text" placeholder="Where you are working" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-3 control-label">Country:</label>
                                        <div class="col-lg-9">
                                             <select name="nation_id"  value="<?php echo e(isset($user->nation_id) ? $user->nation_id : old('nation_id')); ?>" data-placeholder="Select your country" class="form-control required">
                                                <option></option>
                                                <option value="1">Canada</option> 
                                                <option value="2">USA</option> 
                                                <option value="3">Australia</option> 
                                                <option value="4">Germany</option> 
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-3 control-label">Additional message:</label>
                                        <div class="col-lg-9">
                                            <textarea name="message" rows="3" cols="5" class="form-control" placeholder="Enter your message here"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-3 control-label"></label>
                                        <div class="col-lg-9">
                                          <button type="submit" class="btn btn-primary">Save<i class="icon-arrow-right14 position-left"></i></button>
                                        </div>
                                    </div>
                                </fieldset>                              
                            </div>				
					    </form>
					</div>   
				</div>
				<!-- /task overview -->		

			</div>

		
		</div>
		<!-- /Project -->


		<!-- Footer -->

		<!-- /footer -->

	</div>
	<!-- /content area -->

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('core.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>