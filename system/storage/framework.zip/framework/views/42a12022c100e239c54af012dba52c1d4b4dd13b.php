
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $__env->yieldContent('title'); ?></title>

	<!-- Global stylesheets -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="/css/extensions/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
	<link href="/css/extensions/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="/css/extensions/core.css" rel="stylesheet" type="text/css">
	<link href="/css/extensions/components.css" rel="stylesheet" type="text/css">
	<link href="/css/extensions/colors.css" rel="stylesheet" type="text/css">
	<link href="/portals/ico/logo.png" rel="icon" >
	<!-- /global stylesheets -->

	<!-- Core JS files -->
	<script type="text/javascript" src="/js/extensions/plugins/loaders/pace.min.js"></script>
	<script type="text/javascript" src="/js/extensions/core/libraries/jquery.min.js"></script>
	<script type="text/javascript" src="/js/extensions/core/libraries/bootstrap.min.js"></script>
	<script type="text/javascript" src="/js/extensions/plugins/loaders/blockui.min.js"></script>
	<script type="text/javascript" src="/js/extensions/plugins/forms/selects/select2.min.js"></script>
	<script type="text/javascript" src="/js/extensions/plugins/forms/styling/uniform.min.js"></script>
	<script type="text/javascript" src="/js/extensions/pages/form_layouts.js"></script>
	<!-- /core JS files -->


	<!-- Page JS files -->

	<!--/Page JS files -->

</head>

<body class="login-container">

	<!-- Main header -->
	<?php echo $__env->yieldContent('header'); ?>
	<!-- /main header -->


	<!-- Page container -->
	<?php echo $__env->yieldContent('content'); ?>
	<!-- /page container -->

	<!-- Page container -->
	<?php echo $__env->yieldContent('footer'); ?>
	<!-- /page container -->

</body>
</html>
