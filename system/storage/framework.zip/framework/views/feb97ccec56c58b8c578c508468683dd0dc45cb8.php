
<!DOCTYPE html>


<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--<meta name="csrf_token" content="<?php echo csrf_token(); ?>"/>-->
	 <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>Qscompanion</title>

	<script type="text/javascript" src="/js/extensions/core/libraries/jquery.min.js"></script>
	<script type="text/javascript" src="/js/extensions/core/libraries/bootstrap.min.js"></script>



	<link href="css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
	<link href="css/bootstrap_mod.css" rel="stylesheet" type="text/css">
	<link href="css/app.css" rel="stylesheet" type="text/css">

	

  


</head>

<body>
<?php if(Auth::check()): ?>
<div id="app" >
<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
		<?php echo e(csrf_field()); ?>

</form>

<router-view v-if="loggedIn" ></router-view>
			
	
</div>
 <script type="text/javascript" src="js/app.js"></script>
<?php else: ?>
	<script>window.location = "/login";</script>
	
<?php endif; ?>

</body>
</html>

    