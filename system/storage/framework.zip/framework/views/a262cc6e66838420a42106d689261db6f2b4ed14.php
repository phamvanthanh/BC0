
<?php echo $__env->make('pages.users.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>