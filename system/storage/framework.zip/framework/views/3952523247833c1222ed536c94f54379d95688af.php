<?php $__env->startSection('content'); ?>
<!-- Main content -->
<div class="content-wrapper">

	<!-- Page header -->
	<div class="page-header">
		<div class="page-header-content">
			<div class="page-title">
	
				<ul class="breadcrumb position-right">
					<li><a href="/projects"><h5>Projects</h5></a></li>			
					<li class="active">#{Project Id here}</li>
				</ul>
			
			</div>
			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="/projects/id" class="btn btn-link btn-float has-text"><i class="icon-bars-alt text-primary"></i><span>Overview</span></a>
					<a href="/projects/id/schedule" class="btn btn-link btn-float has-text"><i class="icon-calculator text-primary"></i> <span>Schedule</span></a>
					<a href="/projects/id/pwbs" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Pwbs</span></a>
                    <a href="/projects/id/reports" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Reports</span></a>
                    <a href="/projects/id/markdowns" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Markdowns</span></a>
                    <a href="/projects/id/files" class="btn btn-link btn-float has-text"><i class="icon-calendar5 text-primary"></i> <span>Files</span></a>
				</div>
			</div>					
		</div>
	</div>
	<!-- /page header -->
	<!-- Content area -->
    <div class="content" >

            <!-- Project -->
            <div class="row" >
                <div class="col-lg-12" >
                    <!-- Task overview -->
                    <div class="panel panel-flat" >
                        <div class="panel-heading mt-5">
                            <h5 class="panel-title"></h5>						
                        </div>

                        <div class="panel-body" >
                            <form id="" method="post" action="/projects/new"  title="1" form="information_form">
                                <div class="row">
                                
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Name: <span class="text-danger">*</span></label>
                                            <input type="text" name="name" class="form-control required" placeholder="Project's name">
                                        </div>
                                            
                                    </div>
                                    <div class="col-md-4 ">
                                        <div class="form-group">
                                            <label>Client:</label>
                                            <select type="text" name="client_id" value="" class="form-control" >
                                                <option></option>
                                            </select>
                                        </div>														
                                    </div>         

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Nation: <span class="text-danger">*</span></label>
                                            <select name="nation_id" data-placeholder="Select nation"  class="form-control required">
                                                <option></option>
                                    
                                                    <option value="1">United States</option>
                                                    <option value="2">Canada</option>                                        

                                                    <option value="3">Chile</option>
                                                    <option value="4">Argentina</option>
                                                    <option value="5">Colombia</option>
                                                    <option value="6">Peru</option>                                        

                                                    <option value="8">Croatia</option>
                                                    <option value="9">Hungary</option>
                                                    <option value="10">Ukraine</option>                            

                                    
                                                    <option value="21">Egypt</option>
                                                    <option value="22">Israel</option>
                                                    <option value="23">Nigeria</option>
                                                    <option value="24">United Arab Emirates</option>                                     

                                            
                                                    <option value="26">Australia</option>
                                                    <option value="27">China</option>
                                                    <option value="28">India</option>
                                                    <option value="29">Singapore</option>
                                            
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Industry: <span class="text-danger">*</span></label>
                                            <select type="text" name="industry_id"  class="form-control required">
                                                    <option  > </option> 
                                                    <option value="1">Residential and commercial buildings</option> 
                                                    <option value="2">Industrial and power plant</option> 
                                                    <option value="3">Road and bridge</option> 
                                                    <option value="4">Small and private home</option> 
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>From: </label>
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-calendar22"></i></span>
                                                <input type="text" name="from_date" class="form-control daterange-single required" value="">
                                                
                                            </div>
                                        </div>
                                    </div>	
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>To: </label>
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="icon-calendar22"></i></span>
                                                <input type="text" name="to_date" class="form-control daterange-single required" value="">
                                                
                                            </div>
                                        </div>
                                    </div>								
                                </div>								
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Project overview:</label>                                            
                                            <textarea type="text" name="summary"  rows="5" placeholder="Short description about the project" value="" class="form-control"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Requirement:</label>
                                            <textarea type="text" name="requirement" rows="5" placeholder="Descriptive requirement"  value="" class="form-control"></textarea>
                                        </div>
                                    </div>										
                                </div> 
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                                                        
                                            <button type="submit" name="submit"  class="btn btn-primary">Save</button>
                                        </div>
                                    </div>
                                                                            
                                </div>     
                            </form>	
                        </div>   
                    </div>
                    <!-- /task overview -->		

                </div>

            
            </div>
            <!-- /Project -->


            <!-- Footer -->

            <!-- /footer -->

        </div>
        <!-- /content area -->
    </div>
    <!--/Content area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('core.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>