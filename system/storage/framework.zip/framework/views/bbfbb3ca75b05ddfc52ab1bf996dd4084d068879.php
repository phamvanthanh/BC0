<?php $__env->startSection('content'); ?>


<style>

/* Style the tab */
div.tab {
    float: left;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
    width: 100%;
  
}

/* Style the buttons inside the tab */
div.tab button,
div.tab div {
    display: block;
    background-color: inherit;
    color: black;
    padding: 2px 10px;
    width: 100%;
    border: none;
    outline: none;
    text-align: left;
    cursor: pointer;
    transition: 0.3s;
   
}

/* Change background color of buttons on hover */
div.tab button:hover {
    background-color: #ddd;
}

/* Create an active/current "tab button" class */
div.tab button.active {
    /*background-color: #ccc;*/
      /*background-color: #FB8C00;*/
      background-color: #2196F3;
  /*border-color: #FB8C00;*/
  color: #fff;
}

/* Style the tab content */
.tabcontent {
    float: left;
    padding: 0px 12px;
    border: 1px solid #ccc;
    width: 70%;
    border-left: none;
    height: 300px;
}
</style>
<div class="content-wrapper">
    <!-- Page header -->
    <div class="page-header">
        <div class="page-header-content">
            <div class="page-title">
               <ul class="breadcrumb position-right">
                    <li><a href="/projects">Projects</a></li>			
                    <li id="index" data-pid="<?php echo e($pid); ?>"><a href="/projects/<?php echo e($pid); ?>" >#<?php echo e($pid); ?></a></li>
                    <li class="active">Files</li>
                </ul>
            </div>

            <div class="heading-elements">
                <div class="heading-btn-group">
                   <?php echo $__env->make('pages.projects.includes.sub-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>

            
        </div>

    </div>
    <!-- /page header -->


    <!-- Content area -->
    <div class="content" >
    
        <div class="panel panel-flat">
            <div class="panel-heading">
                 <h6 class="panel-title">Document links
                     <a class="heading-elements-toggle"><i class="icon-more"></i></a>
                 </h6>
                <div class="heading-elements">
                    <ul class="icons-list">
                        <li><a data-action="collapse"></a></li>
                    </ul>
                    
                </div>
                
            </div>
          
            <div class="panel-body">  
                <div class="row">
                    <form @submit.prevent="submit" method="post" >
                        <?php echo e(method_field('post')); ?>

                        <?php echo e(csrf_field()); ?>

                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>Caption: <span class="text-danger">*</span></label>
                                <input v-model="curlink.caption" class="form-control required">
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="form-group">
                                <label>Link: <span class="text-danger">*</span></label>
                                <input v-model="curlink.url" class="form-control required">
                            </div>
                        </div>
                        <div class="col-sm-1">
                            <div class="form-group">
                                <label class="transparent" >*</label>
                                <button type="submit" class="btn btn-default form-control">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive"> 
                      <table class="table">
                        <tbody>
                            <tr is="linkrow" v-for="link in links"
                                      v-bind:key="link.id" 
                                      :link ="link">
                                    
                            </tr>
                        </tbody>
                     </table>
                    
                </div>
                
            </div>
      
            
               
        </div>
         <div class="panel panel-flat">
            <div class="panel-heading">
               <h6 class="panel-title">Documents</h6>
                <div class="heading-elements">
                    <ul class="icons-list">
                        <li><a data-action="collapse"></a></li>
                      
                    
                    </ul>
                </div>
            </div>
          
            <div class="panel-body">          
                <div class="row">
                    <div class="col-sm-3">
                   
                        <folders >

                        </folders>
                       


                    </div>
                    <div class="col-sm-9">
                        <filezone>

                        </filezone>
                        
                    </div>
                </div>

            </div>
      
            
               
        </div>
      	

    

    </div>
    <!-- /content area -->
<template id="link-template"> 
    <tr>
        <td class="col-md-3" >{{link.caption}}</td>
        <td class="col-md-7" ><a href="" >{{link.url}}</a></td>
        <td class="col-md-1">
            <ul class="icons-list">
                <li class="text-primary-600" >
                    <a v-on:click="editLink"><i class="icon-pencil7"></i></a>
                </li>
                <li class="text-danger-600" >
                    <a v-on:click="deleteLink" ><i class="icon-trash"></i></a>                   
                </li>
            </ul>
        </td>
    </tr>         
</template>
<template id="folder-template">  
    
    <button v-bind:class="{active: isActive}" @click="activate" class="tablinks" >        
        <span class="fancytree-title" >{{folder.name}}</span>
    </button>
    

</template>
<template id="folders-template">
     <div class="tab">
        <foldercomp v-for="folder in folders"
            v-bind:key="folder.id"
            v-bind:folder="folder">
        </foldercomp>
        <div >
            <span v-if="isNewFolder">
                <form method="post" >
                    <?php echo e(method_field('post')); ?>

                    <?php echo e(csrf_field()); ?>

                    
                    <input type="text" v-model="curfolder.name" placeholder="name" required style="width: 100%" @blur.prevent="submitFolder" >	
                    
                    
                </form>										
            </span>
            <span v-else @click="isNewFolder = true" class="add"  >+</span>
        </div>
    </div>
</template>
<template id="filezone-template">
   
</template>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('core.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>